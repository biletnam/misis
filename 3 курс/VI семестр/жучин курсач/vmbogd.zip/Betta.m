function Betta = Betta(t)

Betta = 0;