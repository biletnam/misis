function F = F(x,t)

F = 0;