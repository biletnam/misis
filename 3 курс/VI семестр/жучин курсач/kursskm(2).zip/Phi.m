function Phi = Phi(x)

Phi = sin(x);
%Phi = 0;