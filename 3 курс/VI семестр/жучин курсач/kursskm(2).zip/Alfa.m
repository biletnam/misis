function Alfa = Alfa(t)

Alfa = 0;