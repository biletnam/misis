function Pci = Pci(x)

Pci = 0;
%if (x>=1.8) & (x<=2) 
 %  Pci = -1;
%end