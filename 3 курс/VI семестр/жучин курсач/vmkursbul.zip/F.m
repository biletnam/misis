function F = F(x,t)

%F = 0;
%if (x>=1.8) & (x<=2.2)
 %  F = 4;
%end
F = 0;